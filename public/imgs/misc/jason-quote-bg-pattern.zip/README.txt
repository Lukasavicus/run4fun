A Pen created at CodePen.io. You can find this one at http://codepen.io/babbardel/pen/BNgZwM.

 A background pattern for a Quote widget.

Based on Lea Verou snippets.