A Pen created at CodePen.io. You can find this one at http://codepen.io/carpenumidium/pen/jbBOxp.

 attempt at a argyle pattern using CSS multiple backgrounds (linear-gradients). my math is top notch stuff ['-____-]